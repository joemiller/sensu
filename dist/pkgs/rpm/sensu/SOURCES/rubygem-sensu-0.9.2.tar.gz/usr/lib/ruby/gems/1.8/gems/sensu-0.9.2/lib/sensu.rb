module Sensu
  VERSION = "0.9.2"
end
